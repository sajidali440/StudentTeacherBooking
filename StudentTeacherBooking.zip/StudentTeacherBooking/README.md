# Student-Teacher Booking Appointment System

A web project where students can book appointments with teachers using Firebase.

## Features:
- Student registration/login
- Admin approval of students
- Admin adds/updates teachers
- Students book appointments
- Teachers approve/reject
- Messaging system
- Firebase Authentication & Firestore used

## Technologies:
HTML, CSS, JavaScript, Firebase

## How to Run:
1. Open index.html in your browser.
2. Make sure Firebase config is added in js/firebase-config.js.
3. All other files work automatically when logged in.

## Folders:
- css/ – styles
- js/ – code files (auth.js, admin.js, etc.)
- *.html – pages for login, dashboard, etc.