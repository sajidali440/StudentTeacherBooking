import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCCbbSRUF9ob2hVTEYe2JxDFDM1nu-Knis",
  authDomain: "studentteacherbooking-28a62.firebaseapp.com",
  projectId: "studentteacherbooking-28a62",
  storageBucket: "studentteacherbooking-28a62.appspot.com",
  messagingSenderId: "1030091413390",
  appId: "1:1030091413390:web:573908f8708f4ba1d1f6df",
  measurementId: "G-ZSV6P18P10"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export { auth, db };