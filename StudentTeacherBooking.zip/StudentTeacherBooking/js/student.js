// js/student.js
import { auth, db } from './firebase-config.js';
import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import {
  collection, addDoc, getDocs, doc, getDoc, query, where
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

let currentUser = null;

// Wait for user to be logged in
onAuthStateChanged(auth, (user) => {
  if (user) {
    currentUser = user;
    loadTeachers();
    loadAppointments();
  } else {
    alert("Not logged in");
    window.location.href = "login.html";
  }
});

// Load all teachers into dropdown
async function loadTeachers() {
  const querySnapshot = await getDocs(collection(db, "teachers"));
  const select1 = document.getElementById("teacherSelect");
  const select2 = document.getElementById("messageTeacher");

  select1.innerHTML = "";
  select2.innerHTML = "";

  querySnapshot.forEach((docSnap) => {
    const data = docSnap.data();
    const option = document.createElement("option");
    option.value = docSnap.id;
    option.text = ${data.name} (${data.subject});

    const option2 = option.cloneNode(true);
    select1.appendChild(option);
    select2.appendChild(option2);
  });
}

// Book Appointment
window.bookAppointment = async function () {
  const teacherId = document.getElementById("teacherSelect").value;
  const time = document.getElementById("appointmentTime").value;
  const purpose = document.getElementById("purpose").value;

  if (!time || !purpose) {
    alert("Fill all fields");
    return;
  }

  await addDoc(collection(db, "appointments"), {
    studentId: currentUser.uid,
    teacherId,
    time,
    purpose,
    status: "pending"
  });

  alert("Appointment requested");
  loadAppointments();
};

// Load My Appointments
async function loadAppointments() {
  const q = query(collection(db, "appointments"), where("studentId", "==", currentUser.uid));
  const querySnapshot = await getDocs(q);
  const container = document.getElementById("myAppointments");
  container.innerHTML = "";

  for (let docSnap of querySnapshot.docs) {
    const data = docSnap.data();
    const teacherSnap = await getDoc(doc(db, "teachers", data.teacherId));
    const teacher = teacherSnap.data();

    const div = document.createElement("div");
    div.innerHTML = `
      With <b>${teacher.name}</b> on <i>${data.time}</i> - ${data.status}<br>Purpose: ${data.purpose}
      <hr>
    `;
    container.appendChild(div);
  }
}

// Send Message
window.sendMessage = async function () {
  const receiverId = document.getElementById("messageTeacher").value;
  const text = document.getElementById("messageText").value;

  if (!text) {
    alert("Enter a message");
    return;
  }

  await addDoc(collection(db, "messages"), {
    senderId: currentUser.uid,
    receiverId,
    text,
    timestamp: new Date()
  });

  alert("Message sent!");
  document.getElementById("messageText").value = "";
};