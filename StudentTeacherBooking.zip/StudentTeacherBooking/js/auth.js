// js/auth.js
import { auth, db } from './firebase-config.js';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import {
  doc, setDoc, getDoc
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

// Registration for student
window.registerStudent = async function () {
  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  try {
    const userCred = await createUserWithEmailAndPassword(auth, email, password);
    await setDoc(doc(db, "users", userCred.user.uid), {
      uid: userCred.user.uid,
      name,
      email,
      role: "student",
      approved: false
    });
    alert("Registered! Waiting for admin approval.");
  } catch (err) {
    alert(err.message);
  }
};

// Login
window.login = async function () {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const role = document.getElementById('role').value;

  if (role === "admin" && email === "admin@admin.com" && password === "admin123") {
    window.location.href = "dashboard-admin.html";
    return;
  }

  try {
    const userCred = await signInWithEmailAndPassword(auth, email, password);
    const docRef = doc(db, "users", userCred.user.uid);
    const userSnap = await getDoc(docRef);
    const user = userSnap.data();

    if (user.role !== role) {
      alert("Role mismatch!");
      return;
    }

    if (role === "student" && !user.approved) {
      alert("Not approved by admin yet.");
      return;
    }

    if (role === "student") {
      window.location.href = "dashboard-student.html";
    } else if (role === "teacher") {
      window.location.href = "dashboard-teacher.html";
    }

  } catch (err) {
    alert(err.message);
  }
};