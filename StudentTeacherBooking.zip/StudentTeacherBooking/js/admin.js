// js/admin.js
import { db } from './firebase-config.js';
import {
  collection, getDocs, updateDoc, doc, deleteDoc, addDoc
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

// Load unapproved students
async function loadStudents() {
  const querySnapshot = await getDocs(collection(db, "users"));
  const container = document.getElementById("students");
  container.innerHTML = "";

  querySnapshot.forEach(async (user) => {
    const data = user.data();
    if (data.role === "student" && data.approved === false) {
      const div = document.createElement("div");
      div.innerHTML = `
        <b>${data.name}</b> (${data.email})
        <button onclick="approveStudent('${user.id}')">Approve</button>
      `;
      container.appendChild(div);
    }
  });
}
window.loadStudents = loadStudents;

// Approve student
window.approveStudent = async function (uid) {
  await updateDoc(doc(db, "users", uid), {
    approved: true
  });
  alert("Student Approved");
  loadStudents();
};

// Add Teacher
window.addTeacher = async function () {
  const name = document.getElementById("tName").value;
  const dept = document.getElementById("tDept").value;
  const subject = document.getElementById("tSubject").value;

  if (!name || !dept || !subject) {
    alert("Please fill all fields");
    return;
  }

  await addDoc(collection(db, "teachers"), {
    name,
    department: dept,
    subject
  });

  alert("Teacher added!");
  document.getElementById("tName").value = "";
  document.getElementById("tDept").value = "";
  document.getElementById("tSubject").value = "";

  loadTeachers();
};

// Load all teachers
async function loadTeachers() {
  const querySnapshot = await getDocs(collection(db, "teachers"));
  const container = document.getElementById("teachers");
  container.innerHTML = "";

  querySnapshot.forEach((docSnap) => {
    const data = docSnap.data();
    const div = document.createElement("div");
    div.innerHTML = `
      <b>${data.name}</b> - ${data.department}, ${data.subject}
      <button onclick="deleteTeacher('${docSnap.id}')">Delete</button>
    `;
    container.appendChild(div);
  });
}
window.loadTeachers = loadTeachers;

// Delete teacher
window.deleteTeacher = async function (id) {
  await deleteDoc(doc(db, "teachers", id));
  alert("Teacher deleted");
  loadTeachers();
};

// Load data on page open
window.onload = () => {
  loadStudents();
  loadTeachers();
};