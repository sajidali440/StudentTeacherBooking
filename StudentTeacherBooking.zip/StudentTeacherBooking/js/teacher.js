// js/teacher.js
import { auth, db } from './firebase-config.js';
import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import {
  collection, getDocs, updateDoc, doc, query, where, getDoc
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

let currentUser = null;

onAuthStateChanged(auth, (user) => {
  if (user) {
    currentUser = user;
    loadAppointments();
    loadMessages();
  } else {
    alert("Not logged in");
    window.location.href = "login.html";
  }
});

// Load appointments
async function loadAppointments() {
  const q = query(collection(db, "appointments"), where("teacherId", "==", currentUser.uid));
  const querySnapshot = await getDocs(q);
  const container = document.getElementById("appointments");
  container.innerHTML = "";

  for (let docSnap of querySnapshot.docs) {
    const data = docSnap.data();
    const studentSnap = await getDoc(doc(db, "users", data.studentId));
    const student = studentSnap.data();

    const div = document.createElement("div");
    div.innerHTML = `
      <b>${student.name}</b> requested appointment on <i>${data.time}</i><br>
      Purpose: ${data.purpose}<br>
      Status: ${data.status}<br>
      <button onclick="updateStatus('${docSnap.id}', 'approved')">Approve</button>
      <button onclick="updateStatus('${docSnap.id}', 'rejected')">Reject</button>
      <hr>
    `;
    container.appendChild(div);
  }
}

// Update appointment status
window.updateStatus = async function (id, newStatus) {
  await updateDoc(doc(db, "appointments", id), {
    status: newStatus
  });
  alert("Status updated to " + newStatus);
  loadAppointments();
};

// Load messages
async function loadMessages() {
  const q = query(collection(db, "messages"), where("receiverId", "==", currentUser.uid));
  const querySnapshot = await getDocs(q);
  const container = document.getElementById("messages");
  container.innerHTML = "";

  for (let docSnap of querySnapshot.docs) {
    const data = docSnap.data();
    const senderSnap = await getDoc(doc(db, "users", data.senderId));
    const sender = senderSnap.data();

    const div = document.createElement("div");
    div.innerHTML = `
      <b>${sender.name}</b>: ${data.text}<br><hr>
    `;
    container.appendChild(div);
  }
}